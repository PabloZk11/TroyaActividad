public class griego extends guerrero {

    public griego(String nombre, int edad, int fuerza){    
        this.nombre = nombre;
        this.edad = (comprobarEdad(edad)) ? edad : 25;
        this.fuerza = (comprobarFuerza(fuerza)) ? fuerza : 5;
    }

    public griego(){}

    public griego(guerrero guerrero1, String nombre) {
        this.nombre = nombre;
        this.edad = guerrero1.getEdad();
        this.fuerza = guerrero1.getFuerza();
        this.herido = guerrero1.getHerido();
        this.muerto = guerrero1.getMuerto();
    }



    @Override
    boolean retirarse() {
        return (herido = true ) ? (true) : (false);
    }
    
    



}
