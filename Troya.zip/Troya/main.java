import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class main {

    public static void main(String[] args) {

        ArrayList<troyano> troyanos = new ArrayList<>();
        ArrayList<griego> griegos = new ArrayList<>();

        Random random = new Random();
        Scanner teclado = new Scanner(System.in);
        int n_contructor = 1;

        if (n_contructor == 1){
            System.out.println(" ");
            System.out.print("El numero del constructor es: " + n_contructor);
            System.out.println(" ");
            System.out.print("Cuantos guerreros deseas generar para cada ejercito (del 1 al 20): ");
            double cantidad_guerreros = teclado.nextDouble();
            System.out.println(" ");
            System.out.println(cantidad_guerreros);

            for(int i = 0; i <= cantidad_guerreros; i++){

                String nombre_troyano = "troyano" + i;

                int edad = random.nextInt(46) + 15;
                int fuerza = random.nextInt(6) + 5;
                int edad_griego = random.nextInt(46) + 15;
                int fuerza_griego = random.nextInt(6) + 5;
                troyano troyano = new troyano(nombre_troyano, edad, fuerza);

                String nombre_griego = "griego" + i; 

                troyanos.add(troyano);

                griego griego = new griego(nombre_griego, edad_griego, fuerza_griego);

                griegos.add(griego);

            }


            for (troyano t : troyanos) {
                System.out.println("Nombre: " + t.getNombre());
                System.out.println("Edad: " + t.getEdad());
                System.out.println("Fuerza: " + t.getFuerza());
                System.out.println();
                

            }

            for (griego t : griegos) {
                System.out.println("Nombre: " + t.getNombre());
                System.out.println("Edad: " + t.getEdad());
                System.out.println("Fuerza: " + t.getFuerza());
                System.out.println();
                

            }

        System.out.print("Para empezar la batalla digite el numero 1, de lo contrario el numero 0: ");
        int empezar = teclado.nextInt();
        System.out.println(" ");
        


            if (empezar == 1) {
            
                int griegos_vivos = 0;
                int griegos_muertos = 0;
                int griegos_heridos = 0;

                int troyanos_vivos = 0;
                int troyanos_muertos = 0;
                int troyanos_heridos = 0;

                for (int i = 0; i < troyanos.size(); i++){

                    int fuerza_peleador1 = troyanos.get(i).getFuerza();
                    int fuerza_peleador2 = griegos.get(i).getFuerza(); 

                    int fuerza_igual = fuerza_peleador1 - fuerza_peleador2;

                    if (fuerza_peleador1 == fuerza_peleador2) {
                        
                        int ganador = random.nextInt(1) + 2;
                        if (ganador == 1) {
                            System.out.println("BATALLA # " + i);
                            System.out.println("El ganador fue el troyano " + troyanos.get(i).getNombre());

                            System.out.println("La fuerza del griego " + griegos.get(i).getNombre() + " ahora es: " + fuerza_igual + " por lo que esta muerto");
                            System.out.println(" ");

                            troyanos_vivos++;
                            griegos_muertos++;

                        }else{
                            System.out.println("El ganador fue el griego " + griegos.get(i).getNombre());

                            System.out.println("La fuerza del troyano " + troyanos.get(i).getNombre() + " ahora es: " + fuerza_igual + " por lo que esta muerto");
                            System.out.println(" ");

                            griegos_vivos++;
                            troyanos_muertos++;

                        }
                    }else if (fuerza_peleador1 >= fuerza_peleador2){

                        int fuerza_griego = fuerza_peleador1 - fuerza_peleador2;
                        System.out.println("BATALLA # " + i);
                        System.out.println("El ganador fue el troyano " + troyanos.get(i).getNombre());
                        
                        if (fuerza_griego >= 1) {
                            System.out.println("La fuerza del griego " + griegos.get(i).getNombre() + " ahora es: " + fuerza_griego + " por lo que esta herido/retidado");
                            System.out.println(" ");

                            troyanos_vivos++;
                            griegos_heridos++;

                        }else if (fuerza_griego == 0) {
                            System.out.println("La fuerza del griego " + griegos.get(i).getNombre() + " ahora es: " + fuerza_griego + " por lo que esta muerto");
                            System.out.println(" ");

                            troyanos_vivos++;
                            griegos_muertos++;
                        }

                    }else if (fuerza_peleador2 >= fuerza_peleador1){

                        int fuerza_troyano = fuerza_peleador2 - fuerza_peleador1;
                        System.out.println("BATALLA # " + i);
                        System.out.println("El ganador fue el griego " + griegos.get(i).getNombre());
                        
                        if (fuerza_troyano >= 1) {
                            System.out.println("La fuerza del troyano " + troyanos.get(i).getNombre() + " ahora es: " + fuerza_troyano + " por lo que esta herido/retidado");
                            System.out.println(" ");

                            griegos_vivos++;
                            troyanos_heridos++;

                        }else if (fuerza_troyano == 0) {
                            System.out.println("La fuerza del troyano " + troyanos.get(i).getNombre() + " ahora es: " + fuerza_troyano + " por lo que esta muerto");
                            System.out.println(" ");

                            griegos_vivos++;
                            troyanos_muertos++;
                        }

                    }

                }

                System.out.println("INFORME FINAL");
                System.out.println(" ");
                System.out.println("INFORME TROYANOS");
                System.out.println("Hay " + troyanos_vivos + " vivos");
                System.out.println("Hay " + troyanos_heridos + " heridos");
                System.out.println("Hay " + troyanos_muertos + " muertos");
                System.out.println(" ");
                System.out.println("INFORME GRIEGOS");
                System.out.println("Hay " + griegos_vivos + " vivos");
                System.out.println("Hay " + griegos_heridos + " heridos");
                System.out.println("Hay " + griegos_muertos + " muertos");
                System.out.println(" ");

                if (griegos_vivos > troyanos_vivos) {
                    System.out.println("LOS GANADORES SON LOS GRIEGOS");
                }else{
                    System.out.println("LOS GANADORES SON LOS TROYANOS");
                }

                
            }else{
                System.out.println("Fin Del Programa");
            }
        }
    }


}
