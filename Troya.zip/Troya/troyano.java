public class troyano extends guerrero{
    
    @Override
    boolean retirarse() {
        return (herido = true ) ? (false) : (false);
    }

    public troyano(String nombre, int edad, int fuerza){    
        this.nombre = nombre;
        this.edad = (comprobarEdad(edad)) ? edad : 25;
        this.fuerza = (comprobarFuerza(fuerza)) ? fuerza : 5;
    }

    public troyano(){
        
        this.nombre = "TroyanoX";
        this.edad = 15;
        this.fuerza = 1;
    }

    public troyano(guerrero troyano1, String nombre) {
        this.nombre = nombre;
        this.edad = troyano1.getEdad();
        this.fuerza = troyano1.getFuerza();
        this.herido = troyano1.getHerido();
        this.muerto = troyano1.getMuerto();
    }


}
