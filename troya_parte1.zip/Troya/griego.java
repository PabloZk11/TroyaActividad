public class griego extends guerrero {

    @Override
    boolean retirarse() {
        return (herido = true ) ? (true) : (false);
    }
    
    



}
