abstract public class guerrero {
    
    protected String nombre;
    protected int edad;
    protected int fuerza;
    protected boolean herido;
    protected boolean muerto;

    public guerrero(String nombre, int edad, int fuerza){    
        this.nombre = nombre;
        this.edad = (comprobarEdad(edad)) ? edad : 25;
        this.fuerza = (comprobarFuerza(fuerza)) ? fuerza : 5;
    }

    public guerrero(){
        
        this.nombre = "GuerreroX";
        this.edad = 15;
        this.fuerza = 1;
    }

    public guerrero(guerrero guerrero1, String nombre) {
        this.nombre = nombre;
        this.edad = guerrero1.getEdad();
        this.fuerza = guerrero1.getFuerza();
        this.herido = guerrero1.getHerido();
        this.muerto = guerrero1.getMuerto();
    }

    public String getNombre(){
        return nombre;
    }

    public int getEdad(){
        return edad;
    }

    public int getFuerza(){
        return fuerza;
    }

    public boolean getHerido(){
        return herido;
    }

    public boolean getMuerto(){
        return muerto;
    }

    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public void setEdad(int edad){
        this.edad = (comprobarEdad(edad)) ? edad : 25;
    }

    public void setFuerza(int fuerza){
        this.fuerza = this.edad = (comprobarFuerza(fuerza)) ? fuerza : 5;
    }

    public void setHerido(boolean herido){
        this.herido = herido;
    }

    public void setMuerto(boolean muerto){
        this.muerto = muerto;
    }

    static boolean comprobarEdad(int edad){
        return (edad >=15 && edad<= 60) ? (true) : (false);
    }

    static boolean comprobarFuerza(int fuerza){
        return (fuerza >=1 && fuerza<= 10) ? (true) : (false);
    }

    abstract boolean retirarse();

}
