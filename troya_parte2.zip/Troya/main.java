import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

public class main {
    
    public static void main(String[] args) {

        ArrayList<troyano> troyanos = new ArrayList<>();
        ArrayList<griego> griegos = new ArrayList<>();

        Random random = new Random();
        Scanner teclado = new Scanner(System.in);
        int n_contructor = random.nextInt(3) + 1;

        if (n_contructor == 1){
            System.out.println(" ");
            System.out.print("El numero del constructor es: " + n_contructor);
            System.out.println(" ");
            System.out.print("Cuantos guerreros deseas generar para cada ejercito (del 1 al 20): ");
            double cantidad_guerreros = teclado.nextDouble();
            System.out.println(" ");
            System.out.println(cantidad_guerreros);

            for(int i = 0; i <= cantidad_guerreros; i++){

                String nombre_troyano = "troyano" + i;

                int edad = random.nextInt(46) + 15;
                int fuerza = random.nextInt(10) + 1;
                int edad_griego = random.nextInt(46) + 15;
                int fuerza_griego = random.nextInt(10) + 1;
                troyano troyano = new troyano(nombre_troyano, edad, fuerza);

                String nombre_griego = "griego" + i; 

                troyanos.add(troyano);

                griego griego = new griego(nombre_griego, edad_griego, fuerza_griego);

                griegos.add(griego);

            }
           
            for (troyano t : troyanos) {
                System.out.println("Nombre: " + t.getNombre());
                System.out.println("Edad: " + t.getEdad());
                System.out.println("Fuerza: " + t.getFuerza());
                System.out.println();
                

        }

            for (griego t : griegos) {
                System.out.println("Nombre: " + t.getNombre());
                System.out.println("Edad: " + t.getEdad());
                System.out.println("Fuerza: " + t.getFuerza());
                System.out.println();
                

        }

        }else if(n_contructor == 2){
            System.out.println(" ");
            System.out.print("El numero del constructor es: " + n_contructor);
            System.out.println(" ");
            System.out.print("Cuantos guerreros deseas generar para cada ejercito (del 1 al 20): ");
            double cantidad_guerreros = teclado.nextDouble();
            System.out.println(" ");
            System.out.println(cantidad_guerreros); 
            
            for(int i = 0; i <= cantidad_guerreros; i++){

                String nombre_troyano = "troyano" + i;

                int edad = random.nextInt(46) + 15;
                int fuerza = random.nextInt(10) + 1;
                troyano troyano = new troyano(nombre_troyano, edad, fuerza);

               String nombre_griego = "griego" + i; 

                troyanos.add(troyano);

                griego griego = new griego(nombre_griego, edad, fuerza);

            }
           
            for (troyano t : troyanos) {
                System.out.println("Nombre: " + t.getNombre());
                System.out.println("Edad: " + t.getEdad());
                System.out.println("Fuerza: " + t.getFuerza());
                System.out.println();
            }

        }else if(n_contructor == 3){
            System.out.println(" ");
            System.out.print("El numero del constructor es: " + n_contructor);
            System.out.println(" ");
            System.out.print("Cuantos guerreros deseas generar para cada ejercito (del 1 al 20): ");
            double cantidad_guerreros = teclado.nextDouble();
            System.out.println(" ");
            System.out.println(cantidad_guerreros); 
            
            for(int i = 0; i <= cantidad_guerreros; i++){

                String nombre_troyano = "troyano" + i;

                int edad = random.nextInt(46) + 15;
                int fuerza = random.nextInt(10) + 1;
                troyano troyano = new troyano(nombre_troyano, edad, fuerza);

               String nombre_griego = "griego" + i; 

                troyanos.add(troyano);

                griego griego = new griego(nombre_griego, edad, fuerza);

            }
           
            for (troyano t : troyanos) {
                System.out.println("Nombre: " + t.getNombre());
                System.out.println("Edad: " + t.getEdad());
                System.out.println("Fuerza: " + t.getFuerza());
                System.out.println();
            }
        }




    }


}
